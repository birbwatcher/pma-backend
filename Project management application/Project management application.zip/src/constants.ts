export const PORT = 3000;
export const SECRET_KEY = 'myVerySecretKey-04.05.2022';